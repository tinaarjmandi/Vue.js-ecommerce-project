<template>
    <!-- Cart Start -->
    <KeepAlive>
        <div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <div class="col-lg-8 table-responsive mb-5">
                <CartTable :datas="datas"></CartTable>
            </div>
            <!-- <div class="col-lg-4">
                <Factor :datas="datas"></Factor>
            </div> -->
        </div>
    </div>
    </KeepAlive>
    <!-- Cart End -->
</template>
<script>
    import CartTable from '../parts/CartParts/Table.vue';
    export default{
        components : {
            CartTable,
        },
        mounted(){
        },
        data(){
            return{
                datas : this.CartData,
            }
        },
        inject : ['CartData'],
        methods : {
            
        },
    }
</script>