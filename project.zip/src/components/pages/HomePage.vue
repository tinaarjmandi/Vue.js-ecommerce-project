<script>
import Featured from '../parts/HomePageParts/Featured.vue'
import Categories from '../parts/HomePageParts/Categories.vue'
import Slider from '../parts/navbar/slider.vue'
import Offer from '../parts/HomePageParts/OfferBanner.vue'
import Latest from '../parts/HomePageParts/LatestSlider.vue'
export default {
  components: {
    Featured,
    Categories,
    Slider,
    Offer,
    Latest
  },
  created(){
  }
};
</script>
<template>
  <Slider></Slider>
  <Featured ></Featured>
  <Offer></Offer>
  <Latest></Latest>
  <div class="text-center mb-4 mt-5">
    <h2 class="section-title px-5">
      <span class="px-2">Categories</span>
    </h2>
  </div>
  <Categories></Categories>
</template>
