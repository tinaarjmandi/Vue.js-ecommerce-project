<script>
export default{

}
</script>
<template>
    <div class="container">
        <h3>
        NOT FOUND :(
    </h3>
    </div>
</template>