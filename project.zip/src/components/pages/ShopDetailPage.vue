<template>
    
<ProductDetail></ProductDetail>


</template>
<script>
    import ProductDetail from '../parts/ShopDetailPageParts/ProductDetail.vue'
    export default{
      components : {
        ProductDetail
      }  
    }
</script>