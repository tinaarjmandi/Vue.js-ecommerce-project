<script>
import axios from "axios";
import Card from "../parts/Productspage/productscard.vue";
export default {
  created() {
    axios.get("/shirts").then((res) => this.cards.push(res.data));
  },
  data() {
    return {
      cards: [],
    };
  },
  components: { Card },
};
</script>
<template>
  <div class="container-fluid pt-5">
    <div class="row px-xl-5">
      <div class="col-lg-4 col-md-6 col-sm-12 pb-1" v-for="n in 34" :key="n">
        <div class="card product-item border-0 mb-4">
          <Card v-for="card in cards" :card="card" :key="card" :n="n"></Card>
        </div>
      </div>
    </div>
  </div>
</template>
