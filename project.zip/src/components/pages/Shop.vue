<script>
import Filters from "../parts/ShopPage/Filters.vue";
import Product from "../parts/ShopPage/Product.vue";
import Pagination from "../parts/ShopPage/Pagination.vue";
import axios from "axios";
export default {
  components: { Filters, Product, Pagination },
  created() {
    axios.get("/products").then((res) => {
      const query = this.$route.query;
      if (Object.keys(query).length) {
        let result = res.data.filter((product) => {
          if (product.title.includes(query.title)) {
            return product;
          }
        });
        this.products = result;
      } else {
        this.products.push(res.data);
      }
    });
  },
  data() {
    return {
      products: [],
      search: {
        title: "",
      },
    };
  },
  provide() {
    return {
      products: this.products,
    };
  },
  methods : {
    Search() {
      const result = "?" + new URLSearchParams(this.search).toString();
      this.$router.push(`/shop${result}`)
    },
  }
};
</script>
<template>
  <div class="container-fluid pt-5">
    <div class="row px-xl-5">
      <Filters></Filters>
      
      <Product v-for="product in products" :product="product" :search="search"></Product>
      <Pagination></Pagination>
    </div>
  </div>
</template>
