<script>
import axios from "axios";
import ShopProducts from '../parts/ShopPageParts/ShopProducts.vue'
export default {
  inject: ["categories", "dresses"],
  mounted() {
  },
  created() {
    axios.get("/products").then((res) => (this.products.push(res.data)));
  },
  data() {
    return {
      products: [],
    };
  },
  components : {
    ShopProducts,
  },
  provide(){
    return {
        products : this.products
    }
  }
};
</script>
<template>
  <ShopProducts v-for="category in categories" :category="category" ></ShopProducts>
</template>
