<template>
  <div class="col-lg-4">
    <div class="card border-secondary mb-5">
      <div class="card-header bg-secondary border-0">
        <h4 class="font-weight-semi-bold m-0">Order Total</h4>
      </div>
      <div class="card-body">
        <div class="d-flex justify-content-between mb-3 pt-1">
          <h6 class="font-weight-medium">Subtotal</h6>
          <h6 class="font-weight-medium">{{ AddData() }}</h6>
        </div>
        <div class="d-flex justify-content-between">
          <h6 class="font-weight-medium">Shipping</h6>
          <h6 class="font-weight-medium">$10</h6>
        </div>
      </div>
      <div class="card-footer border-secondary bg-transparent">
        <div class="d-flex justify-content-between mt-2">
          <h5 class="font-weight-bold">Total</h5>
          <h5 class="font-weight-bold">{{ AddData() + 10 }}</h5>
        </div>
      </div>
    </div>
    <div class="card border-secondary mb-5">
      <div class="card-header bg-secondary border-0">
        <h4 class="font-weight-semi-bold m-0">Payment</h4>
      </div>
      <div class="card-body">
        <div class="form-group">
          <div class="custom-control custom-radio">
            <input
              type="radio"
              class="custom-control-input"
              name="payment"
              id="paypal"
            />
            <label class="custom-control-label" for="paypal">Paypal</label>
          </div>
        </div>
        <div class="form-group">
          <div class="custom-control custom-radio">
            <input
              type="radio"
              class="custom-control-input"
              name="payment"
              id="directcheck"
            />
            <label class="custom-control-label" for="directcheck"
              >Direct Check</label
            >
          </div>
        </div>
        <div class="">
          <div class="custom-control custom-radio">
            <input
              type="radio"
              class="custom-control-input"
              name="payment"
              id="banktransfer"
            />
            <label class="custom-control-label" for="banktransfer"
              >Bank Transfer</label
            >
          </div>
        </div>
      </div>
      <div class="card-footer border-secondary bg-transparent">
        <button
          class="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3"
        >
          Place Order
        </button>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      totals: [],
    };
  },
  inject: ["Data"],
  methods: {
    AddData() {
      let length = this.Data.length;
      for (let i = 0; i < length; i++) {
        this.totals[i] = this.Data[i].total;
        console.log(this.totals);
      }
      let sum = this.totals.reduce((partialSum, a) => partialSum + a, 0);
      return sum;
    },
  },
};
</script>
