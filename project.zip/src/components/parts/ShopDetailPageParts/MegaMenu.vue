<template>
  <div class="row px-xl-5">
    <div class="col">
      <div class="nav nav-tabs justify-content-center border-secondary mb-4">
        <a class="nav-item nav-link active" data-toggle="tab" href="#tab-pane-1"
          >Description</a
        >
        <a class="nav-item nav-link" data-toggle="tab" href="#tab-pane-2"
          >Information</a
        >
        <a class="nav-item nav-link" data-toggle="tab" href="#tab-pane-3"
          >Reviews (0)</a
        >
      </div>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="tab-pane-1">
          <h4 class="mb-3">Product Description</h4>
          <p>{{ product.description }}</p>
        </div>
        <div class="tab-pane fade" id="tab-pane-2">
          <h4 class="mb-3">Additional Information</h4>
          <p>{{ product.info }}</p>
        </div>
        <div class="tab-pane fade" id="tab-pane-3">
          <div class="row">
            
            <div class="col-md-6">
              <h4 class="mb-4">Leave a review</h4>
              <small
                >Your email address will not be published. Required fields are
                marked *</small
              >
              <form>
                <div class="form-group">
                  <label for="message">Your Review *</label>
                  <textarea
                    id="message"
                    cols="30"
                    rows="5"
                    class="form-control"
                  ></textarea>
                </div>
                <div class="form-group">
                  <label for="name">Your Name *</label>
                  <input type="text" class="form-control" id="name" />
                </div>
                <div class="form-group">
                  <label for="email">Your Email *</label>
                  <input type="email" class="form-control" id="email" />
                </div>
                <div class="form-group mb-0">
                  <input
                    type="submit"
                    value="Leave Your Review"
                    class="btn btn-primary px-3"
                  />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: ["product"],
};
</script>
