<template>
  <!-- Shop Detail Start -->
  <div class="container-fluid py-5">
    <div class="row px-xl-5">
      <div class="col-lg-5 pb-5">
        <div id="product-carousel" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner border">
            <div class="carousel-item active">
              <img class="w-100 h-100" :src="product.image" alt="Image" />
            </div>
          </div>
          <a
            class="carousel-control-prev"
            href="#product-carousel"
            data-slide="prev"
          >
            <i class="fa fa-2x fa-angle-left text-dark"></i>
          </a>
          <a
            class="carousel-control-next"
            href="#product-carousel"
            data-slide="next"
          >
            <i class="fa fa-2x fa-angle-right text-dark"></i>
          </a>
        </div>
      </div>

      <div class="col-lg-7 pb-5">
        <h3 class="font-weight-semi-bold">{{ product.title }}</h3>
        <h3 class="font-weight-semi-bold mb-4">{{ product.price + "$" }}</h3>
        <div class="d-flex mb-3">
          <p class="text-dark font-weight-medium mb-0 mr-3">Sizes:</p>
          <form>
            <div class="custom-control custom-radio custom-control-inline">
              <input
                type="radio"
                class="custom-control-input"
                id="size-1"
                name="size"
              />
              <label class="custom-control-label" for="size-1">XS</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input
                type="radio"
                class="custom-control-input"
                id="size-2"
                name="size"
              />
              <label class="custom-control-label" for="size-2">S</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input
                type="radio"
                class="custom-control-input"
                id="size-3"
                name="size"
              />
              <label class="custom-control-label" for="size-3">M</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input
                type="radio"
                class="custom-control-input"
                id="size-4"
                name="size"
              />
              <label class="custom-control-label" for="size-4">L</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input
                type="radio"
                class="custom-control-input"
                id="size-5"
                name="size"
              />
              <label class="custom-control-label" for="size-5">XL</label>
            </div>
          </form>
        </div>
        <div class="d-flex mb-4">
                    <p class="text-dark font-weight-medium mb-0 mr-3">Colors:</p>
                    <form>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="color-1" name="color">
                            <label class="custom-control-label" for="color-1">Black</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="color-2" name="color">
                            <label class="custom-control-label" for="color-2">White</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="color-3" name="color">
                            <label class="custom-control-label" for="color-3">Red</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="color-4" name="color">
                            <label class="custom-control-label" for="color-4">Blue</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="color-5" name="color">
                            <label class="custom-control-label" for="color-5">Green</label>
                        </div>
                    </form>
                </div>
        <!-- btn -->
        <div class="d-flex align-items-center mb-4 pt-2">
          <div class="input-group quantity mr-3" style="width: 130px">
            <div class="input-group-btn">
              <button class="btn btn-primary btn-minus" @click="minus()">
                <i class="fa fa-minus"></i>
              </button>
            </div>
            <input
              type="text"
              class="form-control bg-secondary text-center"
              v-model="quantity"
            />
            <div class="input-group-btn">
              <button class="btn btn-primary btn-plus" @click="add()">
                <i class="fa fa-plus"></i>
              </button>
            </div>
          </div>
          <button class="btn btn-primary px-3" @click="send()">
            <i class="fa fa-shopping-cart mr-1"></i>Add To Cart
          </button>
        </div>
      </div>
    </div>
    <MegaMenu :product="product"></MegaMenu>
  </div>
  <!-- Shop Detail End -->
</template>
<script>

import MegaMenu from "./MegaMenu.vue";
import axios from "axios";
export default {
  created() {
    axios.get(`products/${this.$route.params.id}`).then((res) => (this.product = res.data))
    .catch(err => {
      this.$router.push('/404')
    })
    console.log(this.$route.params)
  },
  data() {
    return {
      product: {},
      quantity : 1,
      ProductData : {
        title : '',
        price : '',
        quantity : '',
        total : 0,
        id : '',
        image : ''
      },
      size : '',
      datas : []
    };
  },
  components: {
    MegaMenu,
  },
  methods: {
    add() {
      if (this.quantity < 10) {
        this.quantity++;
        this.total = this.price + this.price * this.quantity;
      }
    },
    minus() {
      if (this.quantity > 0) {
        this.quantity--;
        this.total = this.total - this.price;
      }
    },
    datas(){
        
    },
    send(){
        this.ProductData.title = this.product.title
        this.ProductData.price = this.product.price
        this.ProductData.quantity = this.quantity
        this.ProductData.id = this.product.id
        this.ProductData.image = this.product.image
        this.ProductData.total = (parseFloat(this.product.price) * parseFloat(this.quantity))
        this.$emit('SendData' , this.ProductData)
        this.ProductData = new Object()
    },
    Send(){
      this.send()
    }
  },
  props : ['n']
};
</script>
