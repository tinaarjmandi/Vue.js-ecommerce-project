<script>
export default {
  
};
</script>
<template>
  <form
  action="mailto:tina.arjmandi@gmail.com" method="get" enctype="text/plain"
    name="sentMessage"
    id="contactForm"
    novalidate="novalidate"
  >
    <div class="control-group">
      <input
        type="text"
        class="form-control"
        id="name"
        placeholder="Your Name"
        data-validation-required-message="Please enter your name"
      />
      <p class="help-block text-danger"></p>
    </div>
    <div class="control-group">
      <input
        type="email"
        class="form-control"
        id="email"
        placeholder="Your Email"
        data-validation-required-message="Please enter your email"
      />
      <p class="help-block text-danger"></p>
    </div>
    <div class="control-group">
      <input
        type="text"
        class="form-control"
        id="subject"
        placeholder="Subject"
        data-validation-required-message="Please enter a subject"
      />
      <p class="help-block text-danger"></p>
    </div>
    <div class="control-group">
      <textarea
        class="form-control"
        rows="6"
        id="message"
        placeholder="Message"
        data-validation-required-message="Please enter your message"
      ></textarea>
      <p class="help-block text-danger"></p>
    </div>
    <div>
      <button
        class="btn btn-primary py-2 px-4"
        type="submit"
        id="sendMessageButton"
      >
        Send Message
      </button>
    </div>
  </form>

<!-- 
<form action="mailto:tina.arjmandi@gmail.com" method="post" enctype="text/plain">
Name:<br>
<input type="text" name="name"><br>
E-mail:<br>
<input type="text" name="mail"><br>
Comment:<br>
<input type="text" name="comment" size="50"><br><br>
<input type="submit" value="Send">
<input type="reset" value="Reset">
</form> -->
</template>
