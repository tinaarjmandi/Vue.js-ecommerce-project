<script>
    export default{
        data(){
            return{
                imgURL : '/public/assets/img/offer-'
            }
        }
    }
</script>
<template>
    <div class="container-fluid offer pt-5">
        <div class="row px-xl-5">
            <div class="col-md-6 pb-4" v-for="n in 2" :key="n">
                <div class="position-relative bg-secondary text-center text-md-right text-white mb-2 py-5 px-5">
                    <img :src="imgURL + n +'.png'" alt="">
                    <div class="position-relative" style="z-index: 1;">
                        <h5 class="text-uppercase text-primary mb-3">20% off the all order</h5>
                        <h1 class="mb-4 font-weight-semi-bold" v-if="n == 1">Spring Collection</h1>
                        <h1 class="mb-4 font-weight-semi-bold" v-else>Winter Collection</h1>
                        <router-link to="/shop" class="btn btn-outline-primary py-md-2 px-md-3">Shop Now</router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>