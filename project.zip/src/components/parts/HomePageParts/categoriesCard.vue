<script>
export default {
  
  data(){
    return{
      imgURL : '/public/assets/img/product-',
    }
  },
  props : ['cover'],
  mounted(){
  },
  inject : ['categories' , 'dresses']
};
</script>
<template>
  <!-- Categories Start -->
  <div class="col-lg-4 col-md-6 pb-1" >
    <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px" >
      <p class="text-right" v-text="cover.quantity" ></p>
      <router-link to="/shop" class="cat-img position-relative overflow-hidden mb-3">
        <img class="img-fluid" :src="imgURL + cover.id + '.jpg'" alt="" />
      </router-link>
      <h5 class="font-weight-semi-bold m-0" v-if="cover.id == 1">{{dresses[1]}}</h5>
      <h5 class="font-weight-semi-bold m-0" v-if="cover.id == 2">{{dresses[2]}}</h5>
      <h5 class="font-weight-semi-bold m-0" v-if="cover.id == 3">{{dresses[0]}}</h5>
    </div>
  </div>
  <!-- Categories End -->
</template>
