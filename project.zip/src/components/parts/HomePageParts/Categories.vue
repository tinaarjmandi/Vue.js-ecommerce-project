<script>
import categoriesCard from "./categoriesCard.vue";
import axios from "axios";
export default {
  created() {
    axios.get("/covers").then((res) => (this.covers = res.data));
  },
  data() {
    return {
      covers: [],
    };
  },
  components: {
    categoriesCard,
  },
  mounted(){
  },
};
</script>
<template>
  <!-- Categories Start -->
  
  <div class="container-fluid pt-5">
    <div class="row px-xl-5 pb-3">
      <categoriesCard :cover="cover"  v-for="cover in covers"  :key="cover">
      </categoriesCard>
    </div>
  </div>
  <!-- Categories End -->
</template>
