<script>
import DropDown from "../navbar/DropDown.vue";
export default {
  components: {
    DropDown,
  },
  data() {
    return {
    };
  },
  created(){
  }
};
</script>
<template>
  <!-- Navbar Start -->
  <div class="container-fluid mb-5">
    <div class="row border-top px-xl-5">
      <DropDown :categories="categories" :dresses="dresses"></DropDown>
      <div class="col-lg-9">
        <nav
          class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0"
        >
          <router-link class="text-decoration-none d-block d-lg-none " to="/home" 
            ><h1 class="m-0 display-5 font-weight-semi-bold">
              <span class="text-primary font-weight-bold border px-3 mr-1"
                >E</span
              >Shopper
            </h1></router-link
          >
          <button
            type="button"
            class="navbar-toggler"
            data-toggle="collapse"
            data-target="#navbarCollapse"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div
            class="collapse navbar-collapse justify-content-between"
            id="navbarCollapse"
          >
            <div class="navbar-nav mr-auto py-0">
              <RouterLink class="nav-item nav-link" to="/home">Home</RouterLink>
              <RouterLink class="nav-item nav-link" to="/shop">Shop</RouterLink>
              <div class="nav-item dropdown">
                <a
                  href="#"
                  class="nav-link dropdown-toggle"
                  data-toggle="dropdown"
                  >Pages</a
                >

                <div class="dropdown-menu rounded-0 m-0">
                  <RouterLink class="nav-item nav-link" to="/cart"
                    >Shopping Cart</RouterLink
                  >
                  <RouterLink class="nav-item nav-link" to="/checkout"
                    >Checkout</RouterLink
                  >
                </div>
              </div>
              <RouterLink class="nav-item nav-link" to="/contact-us"
                >Contact</RouterLink
              >
            </div>
            <div class="navbar-nav ml-auto py-0">
              <RouterLink class="nav-item nav-link" to="/login"
                >Login</RouterLink
              >
              <RouterLink class="nav-item nav-link" to="/register"
                >Register</RouterLink
              >
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>
  <!-- Navbar End -->
</template>
