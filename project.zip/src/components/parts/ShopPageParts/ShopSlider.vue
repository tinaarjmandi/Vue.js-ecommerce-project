<script>
import ProductCard from './ProductCard.vue'
export default {
  inject: ["categories", "dresses" , 'products'],
  mounted() {
    const swiper = new Swiper(".mySwiper", {
      slidesPerView: 1,
      slidesPerColumn: 4,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      },
    );
  },
  
  props: ["category"],
  components : {
    ProductCard
  }
};
</script>
<template>
    <div class="swiper">
    <div class="swiper-container mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide" v-for="n in 2" :key="n">
          <ProductCard v-for="n in 8" :key="n" :n="n"></ProductCard>
        </div>
      </div>
      <div class="swiper-pagination"></div>
    </div>
  </div>
</template>
<style scoped>
    html,
    body {
      position: relative;
      height: 100%;
    }
    
    body {
      background: #eee;
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
      color: #000;
      margin: 0;
      padding: 0;
    }
    
    .swiper-container {
      width: 100%;
      height: 100%;
      margin-left: auto;
      margin-right: auto;
    }
    
    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;
      height: calc((100% - 30px) / 2);
    
      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }
    </style>