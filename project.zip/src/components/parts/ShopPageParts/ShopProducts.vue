<script>
import ShopSlider from './ShopSlider.vue'
export default {
  inject: ["categories", "dresses" , 'products' , 'CartData'],
  mounted() {
    const swiper = new Swiper(".mySwiper", {
      slidesPerView: 1,
      slidesPerColumn: 1,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      },
    );
    
  },
  
  props: ["category"],
  components : {
    ShopSlider
  }
};
</script>
<template>
  <div>
    <div class="text-center mb-4 mt-5">
      <h2 class="section-title px-5">
        <span class="px-2">{{ category }}</span>
      </h2>
    </div>
  </div>
  <ShopSlider ></ShopSlider>
</template>
