<script>
    export default {
      created() {
      },
      data() {
        return {
            img: "/public/assets/img/product-",
        };
      },
      props : ['card' , 'n']
    };
    </script>
    <template>
      
          <div
            class="card-header product-img position-relative overflow-hidden bg-transparent border p-0"
          >
            <img class="img-fluid w-100" :src="card[n].image" alt="" />
          </div>
          <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
            <h6 class="text-truncate mb-3">{{ card[n].name }}</h6>
            <div class="d-flex justify-content-center">
              <h6>{{ card[n].price }}</h6>
            </div>
          </div>
          <div class="card-footer d-flex justify-content-between bg-light border">
            <router-link :to="'/detail/' + n" class="btn btn-sm text-dark p-0"
              ><i class="fas fa-eye text-primary mr-1"></i>View Detail</router-link
            >
          </div>
    </template>
    