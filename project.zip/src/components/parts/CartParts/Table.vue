<template>
  <table class="table table-bordered text-center mb-0">
    <thead class="bg-secondary text-dark">
      <tr>
        <th>Products</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Total</th>
        <th>Remove</th>
      </tr>
    </thead>
    <tbody class="align-middle">
      <tr v-for="(data , index) in Data" :key="data">
        <!-- product -->
        <td class="align-middle">
          {{ data.title }}
        </td>
        <!-- price -->
        <td class="align-middle">{{ data.price }}</td>
        <!-- add -->
        <td class="align-middle">
          <div class="input-group quantity mx-auto" style="width: 100px">
            <td class="align-middle">{{ data.quantity }}</td>
          </div>
        </td>
        <!-- total -->
        <td class="align-middle">{{ data.total }}</td>
        <!-- delete -->
        <td class="align-middle">
          <button class="btn btn-sm btn-primary" @click="Remove(index)">
            <i class="fa fa-times"></i>
          </button>
        </td>
      </tr>
    </tbody>
    <form class="mb-5" action="">
      <div class="input-group">
        <input type="text" class="form-control p-4" placeholder="Coupon Code" />
        <div class="input-group-append">
          <button class="btn btn-primary">Apply Coupon</button>
        </div>
      </div>
    </form>
    <div class="card border-secondary mb-5">
      <div class="card-header bg-secondary border-0">
        <h4 class="font-weight-semi-bold m-0">Cart Summary</h4>
      </div>
      <div class="card-body">
        <div class="d-flex justify-content-between mb-3 pt-1">
          <h6 class="font-weight-medium">Subtotal</h6>
          <h6 class="font-weight-medium">{{ AddData() }}</h6>
        </div>
        <div class="d-flex justify-content-between">
          <h6 class="font-weight-medium">Shipping</h6>
          <h6 class="font-weight-medium">$10</h6>
        </div>
      </div>
      <div class="card-footer border-secondary bg-transparent">
        <div class="d-flex justify-content-between mt-2">
          <h5 class="font-weight-bold">Total</h5>
          <h5 class="font-weight-bold">{{ AddData() + 10 }}</h5>
        </div>
        <router-link to="/checkout">
          <button class="btn btn-block btn-primary my-3 py-3">
            Proceed To Checkout
          </button>
        </router-link>
      </div>
    </div>
  </table>
</template>
<script>
import axios from "axios";
export default {
  data() {
    return {
      products: [],
      totals: [],
    };
  },
  created() {
    axios.get("/products").then((res) => (this.products = res.data));
  },
  mounted() {},
  inject: ["Data"],
  methods: {
    Remove(index) {
      console.log(this.AddData())
      this.Data.splice(index,1)
      this.totals.splice(index , 1)
      this.AddData()
    },

    AddData() {
      let length = this.Data.length
      for(let i=0 ; i < length; i++){
        this.totals[i] = this.Data[i].total
      }
      let sum = this.totals.reduce((partialSum, a) => partialSum + a, 0);
      return sum
    },
    minusData(){
      console.log(this.sum)
    }
  },
};
</script>
