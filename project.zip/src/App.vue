<script>
import Header from "./components/parts/header/Header.vue";
import NavBar from "./components/parts/navbar/NavBar.vue";
import Footer from "./components/parts/footer/Footer.vue";
export default {
  components: {
    NavBar,
    Header,
    Footer,
  },
  data() {
    return {
      categories: [
        "Shirts",
        "Jeans",
        "Swimwear",
        "Sleepwear",
        "Sportswear",
        "Jumpsuits",
        "Blazers",
        "Jackets",
        "Shoes",
      ],
      dresses: ["Men's Dresses", "Women's Dresses", "Baby's Dresses" ],
      CartData : {
        datas : ''
      },
      Data :[],
    };
  },
  provide() {
    return {
      categories : this.categories,
      dresses : this.dresses,
      CartData : this.CartData,
      Data : this.Data
    }
  },
  methods: {
    
    GetData(data){
      this.Data.push(data)
    },
    final(){
      

    }
  },
  mounted(){

  }
};
</script>
<template>
  <Header></Header>
  <NavBar></NavBar>
  <router-view v-on:SendData="GetData($event)"></router-view>
  <Footer></Footer>
  <a href="#" class="btn btn-primary back-to-top"
    ><i class="fa fa-angle-double-up"></i
  ></a>
</template>
