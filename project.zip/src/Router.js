import { createRouter, createWebHistory } from "vue-router";

import HomePageVue from './components/pages/HomePage.vue';
import ShopPage from './components/pages/ShopPage.vue';
import ContactPageVue from './components/pages/ContactPage.vue';
import CheckOutPage from './components/pages/CheckOutPage.vue';
import DetailPage from './components/pages/ShopDetailPage.vue';
import ShoppingCart from './components/pages/ShoppingCart.vue'
import NotFound from './components/pages/NotFoundPage.vue'
import Shop from './components/pages/Shop.vue'
import products from './components/pages/Products.vue'
const router = createRouter({
    history : createWebHistory(),
    routes : [
        {path : '/home' , component : HomePageVue},
        {path : '/shop' , component : Shop},
        {path : '/products' , component : products},
        {path : '/contact-us' , component : ContactPageVue},
        {path : '/checkout' , component : CheckOutPage},
        {path : '/detail/:id' , component : DetailPage , name : 'detail'},
        {path : '/cart' , component : ShoppingCart , name : 'cart'},
        {path : '/404' , component : NotFound},

    ]
})

export default router