import { createApp } from 'vue'

import App from './App.vue'
import router from './Router.js'
import axios from 'axios'
axios.defaults.baseURL = 'https://633327cd573c03ab0b5946e3.mockapi.io'

let app = createApp(App)
app.use(router)
app.mount('#app')